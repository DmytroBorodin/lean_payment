import React from "react";
import './AddBusinessCard.css';

const AddBusinessCard = (props) => {
    return (
        <div className='add__business__card__btn'>
            <p className="card__btn__text">
                Creat Business Account
            </p>
            <div className="plus__btn">

            </div>
        </div>
    )
}

export default AddBusinessCard;